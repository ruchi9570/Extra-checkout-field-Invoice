<?php
// ** Silence is golden