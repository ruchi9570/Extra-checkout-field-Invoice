<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of VatValidator
 *
 * @author Sachin
 */
class VatValidator
{


    function __construct()
    {
        
    }

    /**
     * todo: add validation for VAT 
     * @param type $data
     */
    public function validate($data)
    {

        return true;
    }
}
